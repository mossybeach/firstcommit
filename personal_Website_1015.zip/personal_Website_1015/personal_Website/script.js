
/********************************* 
                    GNB 메뉴 오버시 움직이는 배경
                *********************************/
const gnb = document.querySelectorAll(".nav_gnb li");
const mbg = document.querySelector(".mbg");

gnb.forEach((ele) => {
  ele.onmouseenter = (e) => {
    let eLeft = ele.offsetLeft;
    let eWidth = ele.offsetWidth;

    console.log("left:", eLeft, "\nwidth:", eWidth);

    mbg.style.left = eLeft + "px";
    mbg.style.width = eWidth + "px";
    mbg.style.opacity = 1;
  };

  ele.onmouseleave = (e) => {
    mbg.style.opacity = 0;
  };
});

/******************* slide scroller
 *****************************/