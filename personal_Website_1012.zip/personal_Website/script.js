// 1. 타겟 박스
const music = document.querySelector(".music");
// 2. 스티키 박스
const slideMusic = document.querySelector(".slidemusic");
// 2. 가로 이동 박스 slideMusic ul

makeList();

const mvbx = slideMusic.querySelector("ul");

window.addEventListener("scroll", movePage);

const retVal = (x) => x.getBoundingClientRect().top;

function movePage() {
  let tgpos = retVal(tpg);

  if (tgpos <= 0 && tgpos >= -3000) {
    mvbx.style.left = tgpos + "px";
  } else if (tgpos > 0) {
    mvbx.style.left = "0";
  }
}

function makeList() {
  let hcode = "<ul>";

  for (let x = 1; x < 5; x++) {
    hcode += `
    <li>
      <img src="/img/${x}.jpg" alt= "toys">
      </li>
    `;
  }
  hcode += "</ul>";
  music.innerHTML = hcode;
}

const gnb = document.querySelectorAll(".nav_gnb li");
const mbg = document.querySelector(".mbg");

gnb.forEach((ele) => {
  ele.onmouseenter = (e) => {
    let eLeft = ele.offsetLeft;
    let eWidth = ele.offsetWidth;

    console.log("left:", eLeft, "\nwidth:", eWidth);

    mbg.style.left = eLeft + "px";
    mbg.style.width = eWidth + "px";
    mbg.style.opacity = 1;
  };

  ele.onmouseleave = (e) => {
    mbg.style.opacity = 0;
  };
});
